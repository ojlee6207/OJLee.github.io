import  { useState, useEffect } from 'react'

export default function TodoItem() {
    const [schList, setSchList] = useState([]);

    useEffect(()=>{
        setSchList([
            {no: "", contents: "", startdate: ""}
            // {checked: false, no:1, title: '내 스케쥴표1', date:'2024-03-22'},
            // {checked: false, no:2, title: '내 스케쥴표2', date:'2024-02-22'},
            // {checked: true, no:3, title: '내 스케쥴표3', date:'2024-01-25'},
        ])
    }, []);


    function updateSch(idx) {
        let list = [...schList];
        schList.push(idx, 1);
        setSchList(list);
    }

    function deleteSch(idx) {
        let list = [...schList];
        schList.splice(idx, 1);
        setSchList(list);
    }

    return (
        <div className="ToDoItem">
            <table>
                <tbody>
                    {
                        schList.map((schedule, idx) => {
                            return (
                                <tr key={"schedule"}>
                                    <td><input type="checkbox" /></td>
                                    <td>{schedule.no}</td>
                                    <td>{schedule.contents}</td>
                                    <td>{schedule.startdate}</td>
                                    <td><button onClick={()=>updateSch(idx)}>수정</button></td>
                                    <td><button onClick={()=>deleteSch(idx)}>삭제</button></td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
        </div>
    )
}