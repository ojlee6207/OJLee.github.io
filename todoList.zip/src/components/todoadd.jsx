import '../css/todoadd.scss'
import React, {useState, useEffect} from 'react'

export default function ToDoAdd() {

    const [reportSch, setReportSch] = useState([]);
    const [contents, setContents] = useState("");
    const [startdate, setStartdate] = useState("");

    useEffect(()=>{
        console.log(reportSch)
    }, [reportSch])
    

    function writeSch (ev) {
        setContents(ev.target.value);
    }

    function dateSch (ev) {
        setStartdate(ev.target.value);
    }

    function reportSchPlus() {
        let scheduleArr = [contents, startdate]

        scheduleArr.push(contents, startdate);
        setReportSch(scheduleArr);
    }

    return (
        <div className="ToDoAdd">
            <input type="text" value={contents} onChange={writeSch} placeholder="ToDo 적기" />
            <input type="date" value={startdate} onChange={dateSch} />
            <button type="submit" onClick={reportSchPlus}>등록하기</button>
        </div>
    )
}