import ToDoItem from '../components/todoitem'
import { useState } from 'react'

export default function ToDoList() {
    const [todos, setTodos] = useState("");

    return (
        <div className="ToDoList">
            { todos.map((todo) => (
                <ToDoItem todo={todo} key={todo.idx} />
            ))}            
        </div>
    )
}