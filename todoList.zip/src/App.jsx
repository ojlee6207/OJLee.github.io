import './App.css'
import Header from './components/header'
import ToDoAdd from './components/todoadd'
// import ToDoList from './components/todolist'

export default function App() {

  return (
    <div className="App">
      <Header />
      <ToDoAdd />
      {/* <ToDoList /> */}
    </div>
  );
}
