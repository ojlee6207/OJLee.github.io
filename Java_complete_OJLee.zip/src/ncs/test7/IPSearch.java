package ncs.test7;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;

public class IPSearch {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.print("호스트명 : ");
		String host = sc.nextLine();
		int i = 1;
		
		try {
			InetAddress[] ipHost = InetAddress.getAllByName(host);
			System.out.println(host+"는 "+ipHost.length+"개의 IP주소를 가지고 있습니다.");
			for(InetAddress realIP : ipHost) {	// for(배열 데이터 타입| 변수명 : 배열변수명)
				System.out.println(i+"번 IP : " + realIP.getHostAddress());
				i++;
			}
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}	

	}

}
