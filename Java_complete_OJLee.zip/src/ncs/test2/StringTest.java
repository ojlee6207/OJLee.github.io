package ncs.test2;

import java.util.Arrays;
import java.util.StringTokenizer;

public class StringTest {

	public static void main(String[] args) {
		String str = "A, b, c, D, a, B, C, d, f, F";
		
		StringTokenizer s = new StringTokenizer(str, ", ");

		String[] st = str.split(", ");
		/* str에서 ', ' 로 데이터 분리	*/;
		// st => char[]

		char[] data = new char[st.length];/* 배열 할당 */
		
		int i = 0;
				
		for(String ch : st) {	// for~each
			data[i] = ch.charAt(0);
			System.out.print(data[i]+" ");
			i++;
		}
		System.out.println();
		// char[]에서 대문자만 골라 출력한다. continue 쓰기
		i = 0;
		while(i<data.length) {	// while loop 쓰기
			if(data[i]>='A' && data[i]<= 'Z') {
				System.out.printf("data[%d] : %c\n", i, data[i]);
				i++;
				continue;
			} else {
				i++;
				continue;
			}

		}	

	}

}
