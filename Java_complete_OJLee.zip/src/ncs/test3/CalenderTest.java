package ncs.test3;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Scanner;

public class CalenderTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("날짜를 입력하시오.");
		System.out.print("년 : ");
		String year = sc.nextLine();
		System.out.print("월 : ");
		String month = sc.nextLine();
		System.out.print("일 : ");
		String day = sc.nextLine();
		
		String date = year+month+day;
		System.out.println(date.toString());
		String f = "20110213";
		SimpleDateFormat ss = new SimpleDateFormat("yyyy년 MM월 dd일 E요일", Locale.KOREAN);
		System.out.println(ss.format(f));
		
		System.out.println();

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 E요일", Locale.KOREAN);
		
		GregorianCalendar gc = new GregorianCalendar();
		int nYear = Integer.parseInt(year);
				
		System.out.println("입력된 날짜에 대한 정보는 다음과 같습니다.");
		System.out.println(sdf.format(date.toString()));
		
//		if(GregorianCalendar.isLeapYear(nYear)) {
//			System.out.printf("%d년은 윤년입니다", year);
//		} else {
//			System.out.printf("%d년은 평년입니다", year);
//		}
//		
	}

}
