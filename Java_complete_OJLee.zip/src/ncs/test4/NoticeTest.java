package ncs.test4;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class NoticeTest {

	public static void main(String[] args) {
		Object[] obArray = new Object[3];
		Scanner sc = new Scanner(System.in);
		Notice nt = new Notice();
		String day = null;
		for(int i=0; i<1; i++) {
			System.out.println("등록할 공지사항을 입력하시오.(3번 반복 입력 처리함)");
			System.out.print("제목 : ");
			String title = sc.nextLine();
			nt.setTitle(title);
			try {
				do {
					System.out.print("등록일 (yyyy-MM-dd로 입력하시오): ");
					day = sc.nextLine();
					if(day.length()!=10) {
						System.out.println("다시 입력하시오.");
					}
				} while(day.length() !=10);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				nt.setDate(sdf.parse(day));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			System.out.print("작성자 : ");
			String writer = sc.nextLine();
			nt.setWriter(writer);
			System.out.print("내용 : ");
			String content = sc.nextLine();
			nt.setContent(content);
			int no = i+1;
			
			obArray[i] = new Notice(no, title, nt.getDate(), writer, content);
		}
		for(int i=0; i<1; i++) {
			System.out.println(obArray[i].toString());
		}
	}
	/*
	public void fileSave(Object[] array) {
		try {
			FileOutputStream fos = new FileOutputStream("notice.dat");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<Notice> fileRead() {
		
	}
*/
}
