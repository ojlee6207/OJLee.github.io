package ncs.test1;

import java.util.Random;
import java.util.Scanner;

public class ArrayTest {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Random rand = new Random();
		
		System.out.print("할당 된 배열의 크기 : ");
		int size = sc.nextInt();
		int[] arr = new int[size];
		for(int i=0; i<size ; i++) {
			arr[i] = rand.nextInt(100)+1;
		}
		System.out.print("Array : ");
		print(arr);
		System.out.println("\n가장 큰 값 : " + max(arr));
		System.out.println("가장 작은 값 : " + min(arr));
		System.out.println("짝수의 개수 : " + evenCount(arr));
		System.out.println("홀수의 개수 : " + oddCount(arr));
		System.out.println("합계 : " + sum(arr));
		System.out.printf("평균 : %.2f", avg(arr));

	}

	public static int sum(int[] arr) {
		int tot_sum = 0;
		for(int i=0; i<arr.length; i++) {
			tot_sum += arr[i];
		}
		return tot_sum;
	}
	
	public static double avg(int[] arr) {
		double average = (double)sum(arr)/(arr.length);
		return average;
	}
	
	public static int max(int[] arr) {
		int max_value = arr[0];
		for(int max : arr) {
			if(max_value < max) {
				max_value = max;
			}
		}
		return max_value;
	}
	
	public static int min(int[] arr) {
		int min_value = arr[0];
		for(int min : arr) {
			if(min_value > min) {
				min_value = min;
			}
		}
		return min_value;
	}
	
	public static int evenCount(int[] arr) {
		int count = 0;
		for(int even : arr) {
			if(even%2 == 0) count++;
		}
		return count;
	}
	
	public static int oddCount(int[] arr) {
		int count = 0;
		for(int odd : arr) {
			if(odd%2 == 1) count++;
		}
		return count;
	}
	
	public static void print(int[] arr) {
		for(int array : arr) {
			System.out.print(array+"\t");
		}
	}
}
