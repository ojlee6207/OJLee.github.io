package ncs.test5;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class PhoneMapTest {

	public static void main(String[] args) {
		Map<String, Phone> map = new HashMap<String, Phone>();
		Properties prop = new Properties();
		
		Phone gal = new Phone("Galaxy S7", 563500, "삼성", 7);
		Phone iph = new Phone("iphone 6s", 840000, "애플", 3);
		Phone g = new Phone("G5", 563500, "LG", 5);
		
		map.put(gal.getModel(), gal); 
		map.put(iph.getModel(), iph); 
		map.put(g.getModel(), g); 
	
		System.out.println("맵에 저장된 정보는 다음과 같습니다.");
		for (Map.Entry<String, Phone> entrySet : map.entrySet()) {	
			System.out.println(entrySet.getKey()+" : " +entrySet.getValue());	
		}

		prop.setProperty(gal.getModel(), gal.toString());
		prop.setProperty(iph.getModel(), iph.toString());
		prop.setProperty(g.getModel(), g.toString());
		// 위에서 미리 저장하고, 아래에서 xml파일로 만들어서 저장하기.
		
		try {
			prop.storeToXML(new FileOutputStream("phone.xml"),"Phone Info");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			System.out.println("Phone.xml 파일에 성공적으로 저장되었습니다.");
		}
		/*
		
		try {
			OutputStream stream = new FileOutputStream("phone.xml");
			prop.store(stream, gal.toString());		
			prop.store(stream, iph.toString());
			prop.store(stream, g.toString());
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			System.out.println("Phone.xml 파일에 성공적으로 저장되었습니다.");
		}

		 */
	}

}
