package ncs.test6;

public class EmptyException extends Exception{
	public EmptyException() {
		super("현재 입력된 값이 없습니다. 기다리십시오...");
	}
	
	public EmptyException(String message) {
		super(message);
	}
}
