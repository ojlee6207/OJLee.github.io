package ncs.test6;

public class MultiThreadTest {

	public static void main(String[] args) {
		Data data = new Data();
		Thread putThread;
		Thread getThread;
		
		Provider pv = new Provider(data);
		Customer cm = new Customer(data);
		
		putThread = new Thread(pv);
		getThread = new Thread(cm);
		
		putThread.setPriority(7);
		getThread.setPriority(3);
		
		try {
			putThread.start();
			getThread.start();

			putThread.join();
			getThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
