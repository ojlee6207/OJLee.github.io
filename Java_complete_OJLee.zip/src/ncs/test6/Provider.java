package ncs.test6;

public class Provider extends Thread{
	private Data data;

	public Provider(Data data) {
		this.data = data;
	}
	
	@Override
	public void run() {
		for(int i=1 ; i<=10 ; i++) {
			int random = (int)(Math.random()*100+1);
			try {
//				System.out.println(">>>>>>>>>>>>>> Provider:setValue 호출전");
				data.setValue(random);
				System.out.printf("값이 입력되었습니다.\nput value : "
						+ "%d\n", data.getValue());
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			} catch (EmptyException e) {
				e.printStackTrace();
			}
		}
	}
}
