package ncs.test6;

public class Data {
	private int value;
	private boolean isEmpty = true;
	
	public Data() {	}
	
	public synchronized int getValue() {
//		System.out.println(">>>>>>>>>>>>>> Customer:getValue 동작");
		if(isEmpty == false)
			isEmpty = true;
			return value;
	}

	public synchronized void setValue(int value) throws EmptyException {
//		System.out.println(">>>>>>>>>>>>>> Provider:setValue 동작");
		if(isEmpty == true) {
			this.value = value;
			isEmpty = false;
		} else {
			EmptyException ee = new EmptyException();
			throw ee;
		}
	}
	
/*
	public int getValue() {
		synchronized (this){
			System.out.println(">>>>>>>>>>>>>> Customer:getValue 동작");
		if(isEmpty == false)
			isEmpty = true;
			return value;
		}
	}
	public void setValue(int value) throws EmptyException {
		synchronized (this) {
			System.out.println(">>>>>>>>>>>>>> Provider:setValue 동작");
		if(isEmpty == true) {
			this.value = value;
			isEmpty = false;
		} else {
			throw new EmptyException("현재 입력된 값이 없습니다. 기다리십시오...");
		}
		}
	}
	*/
}
