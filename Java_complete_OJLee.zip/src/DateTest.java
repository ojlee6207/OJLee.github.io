import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateTest {

	public static void main(String[] args) {
		
		String sDate = "20130422";
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 E요일",Locale.KOREAN);
		
		try {
			Date ndate = sdf.parse(sDate);
			System.out.println(ndate);
			String toDate = sdf.format(sDate);
			System.out.println(sDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
}
